# find . -maxdepth 1 -type f -name "*.jaspar" | sed 's|^\./||; s|\.jaspar$||' > jaspar_IDs.txt

from pyjaspar import jaspardb
import sys

# jdb_obj = jaspardb(release='JASPAR2024')
# motif = jdb_obj.fetch_motif_by_id(jaspar_id)

def main(jaspar_ids_txt):
    # Initialize JASPAR database object
    release_dict = dict()






import os
import requests
import sys

# Cache for UniProt sequences
sequences_by_uniprot = {}


def get_sequence_from_uniprot_id(uniprot_id):
    """
    Fetches the FASTA sequence for a given UniProt ID.
    Caches the sequence to avoid redundant API calls.
    """
    if uniprot_id in sequences_by_uniprot:
        return sequences_by_uniprot[uniprot_id]

    url = 'https://rest.uniprot.org/uniprotkb/search'
    url_params = {'format': 'fasta', 'query': f'accession:{uniprot_id}'}

    try:
        response = requests.get(url, params=url_params)
        response.raise_for_status()
        seq = ''.join(response.text.split('\n')[1:])  # Skip the header line
        sequences_by_uniprot[uniprot_id] = seq  # Cache the sequence
        return seq
    except requests.exceptions.RequestException as e:
        print(f"Error fetching UniProt ID {uniprot_id}: {e}")
        return None


def process_transfac_file(jaspar_file):

    output_fasta_file = os.path.splitext(jaspar_file)[0] + ".fasta"

    with open(jaspar_file, 'r') as file, open(output_fasta_file, 'w') as fasta_output:
        uniprot_ids = []
        for line in file:
            if line.startswith("CC uniprot_ids:"):
                ids_line = line.strip().split(":")[1]  # Extract IDs after "CC uniprot_ids:"
                uniprot_ids = [id_.strip() for id_ in ids_line.split(";")]

        # Fetch sequences for each UniProt ID and write them to the FASTA file
        for uniprot_id in uniprot_ids:
            sequence = get_sequence_from_uniprot_id(uniprot_id)
            if sequence:
                fasta_output.write(f">{uniprot_id}\n{sequence}\n")

    print(f"FASTA file created: {output_fasta_file}")


def main(directory):
    """
    Processes all JASPAR files in the given directory.
    """
    for file_name in os.listdir(directory):
        if file_name.endswith(".transfac"):
            transfac_file_path = os.path.join(directory, file_name)
            print(f"Processing {transfac_file_path}...")
            process_transfac_file(transfac_file_path)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python extract_uniprot_sequences.py <jaspar_directory>")
        sys.exit(1)

    transfac_directory = sys.argv[1]
    if not os.path.isdir(transfac_directory):
        print(f"Error: {transfac_directory} is not a valid directory.")
        sys.exit(1)

    main(transfac_directory)

