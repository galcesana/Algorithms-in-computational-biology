import os
import torch
import torch.nn as nn
import torch.optim as optim

from esm import pretrained

import numpy as np
from torch.utils.data import Dataset, DataLoader, random_split
from sklearn.model_selection import train_test_split


# Neural network model for matrix prediction
class MatrixPredictionModel(nn.Module):
    def __init__(self, embedding_size: int, matrix_size: int):
        super(MatrixPredictionModel, self).__init__()
        self.fc1 = nn.Linear(embedding_size, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, matrix_size)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x


import os
import torch
import esm
from torch.utils.data import Dataset, DataLoader, random_split

class SequenceMatrixDataset(Dataset):
    def __init__(self, sequences, matrices, embedding_size, embeddings=None):
        """
        sequences: list of protein sequences
        matrices: list of corresponding matrices
        embedding_size: size of the protein embedding
        embeddings: pre-computed embeddings (optional)
        """
        self.sequences = sequences
        self.matrices = matrices
        self.embedding_size = embedding_size
        self.embeddings = embeddings if embeddings is not None else []

        # If embeddings are not precomputed, compute them here
        if not self.embeddings:
            self.embeddings = [get_protein_embedding(seq) for seq in self.sequences]

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        # Return the embedding and corresponding matrix for the given index
        return self.embeddings[idx], self.matrices[idx]

model, alphabet = pretrained.esm2_t33_650M_UR50D()
batch_converter = alphabet.get_batch_converter()
def get_protein_embedding(sequence: str) -> torch.Tensor:
    """
    Given a protein sequence, return the corresponding protein embedding
    """
    data = [("protein", sequence)]
    _, _, batch_tokens = batch_converter(data)

    model.eval()
    with torch.no_grad():
        results = model(batch_tokens, repr_layers=[33])
        token_representations = results["representations"][33]

    sequence_embedding = token_representations.mean(1).squeeze(0)
    return sequence_embedding

def save_dataset(dataset, filename):
    torch.save(dataset, filename)
    print(f"Dataset saved to {filename}")

def load_dataset(filename):
    dataset = torch.load(filename)
    print(f"Dataset loaded from {filename}")
    return dataset


def make_dataset(transfac_ids_file, directory, embedding_size=1280, batch_size=32, test_size=0.2, dev_size=0.1):
    with open(transfac_ids_file, 'r') as f:
        transfac_ids = [line.strip() for line in f if line.strip()]

    all_sequences = []
    all_matrices = []
    all_embeddings = []

    # Process each transfac ID
    for transfac_id in transfac_ids:
        transfac_file = os.path.join(directory, f"{transfac_id}.transfac")
        fasta_file = os.path.join(directory, f"{transfac_id}.fasta")

        if not os.path.isfile(transfac_file):
            print(f"Transfac file {transfac_file} not found. Skipping...")
            continue

        if not os.path.isfile(fasta_file):
            print(f"FASTA file {fasta_file} not found. Skipping...")
            continue

        # Read matrix from transfac file
        matrix = []
        with open(transfac_file, 'r') as tf:
            matrix_section = False
            for line in tf:
                line = line.strip()
                if line.startswith("PO"):
                    matrix_section = True
                elif matrix_section:
                    if line.startswith("XX"):  # End of matrix section
                        matrix_section = False
                    else:
                        # Extract numeric matrix row
                        parts = line.split()
                        if parts[0].isdigit():
                            matrix.append([float(x) for x in parts[1:]])

        # Read sequences from fasta file and save embeddings
        with open(fasta_file, 'r') as ff:
            current_id = None
            current_seq = []
            for line in ff:
                if line.startswith(">"):
                    if current_id and current_seq:
                        sequence = "".join(current_seq)
                        embedding = get_protein_embedding(sequence)

                        # Create embedding filename using both IDs
                        embedding_filename = f"{transfac_id}_{current_id.replace('|', '_')}.embedding"
                        embedding_path = os.path.join(os.path.dirname(fasta_file), embedding_filename)

                        # Save embedding to file
                        np.save(embedding_path, embedding)

                        # Add to dataset lists
                        all_sequences.append(sequence)
                        all_matrices.append(matrix)
                        all_embeddings.append(embedding)

                    current_id = line[1:].strip()
                    current_seq = []
                else:
                    current_seq.append(line.strip())

            # Process the last sequence
            if current_id and current_seq:
                sequence = "".join(current_seq)
                embedding = get_protein_embedding(sequence)

                # Create embedding filename using both IDs
                embedding_filename = f"{transfac_id}_{current_id.replace('|', '_')}.embedding"
                embedding_path = os.path.join(os.path.dirname(fasta_file), embedding_filename)

                # Save embedding to file
                np.save(embedding_path, embedding)

                # Add to dataset lists
                all_sequences.append(sequence)
                all_matrices.append(matrix)
                all_embeddings.append(embedding)

    # Create dataset object
    dataset = SequenceMatrixDataset(all_sequences, all_matrices, embedding_size, all_embeddings)

    # Split the data into train, dev, and test sets
    train_size = int((1 - test_size - dev_size) * len(dataset))
    dev_size = int(dev_size * len(dataset))
    test_size = len(dataset) - train_size - dev_size

    train_dataset, dev_dataset, test_dataset = random_split(dataset, [train_size, dev_size, test_size])

    # Create data loaders
    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    dev_dataloader = DataLoader(dev_dataset, batch_size=batch_size, shuffle=False)
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    return train_dataloader, dev_dataloader, test_dataloader



if __name__ == "__main__":

    # Paths to the files
    transfac_ids_file = "/cs/76562/davidgersh2004/hackathon_CBIO/transfac_IDs.txt"
    directory = "/cs/76562/davidgersh2004/hackathon_CBIO/JASPAR2024_CORE_non-redundant_pfms_transfac"

    # Train the model, it will load the dataset if it exists or generate it if not
    make_dataset(transfac_ids_file, directory)


    # Load the model (if needed later)
    # model.load_state_dict(torch.load("matrix_prediction_model.pth"))








